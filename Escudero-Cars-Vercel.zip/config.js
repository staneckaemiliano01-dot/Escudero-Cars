window.SUPABASE_URL='https://llsjstxuesvrjthzjkio.supabase.co';
window.SUPABASE_KEY='sb_publishable_IJ2_r8cpE8JsURqINYGYxg_8Qw5nPez';
